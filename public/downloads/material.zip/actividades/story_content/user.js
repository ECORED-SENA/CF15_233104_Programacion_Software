function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5mB9TlC5324":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

